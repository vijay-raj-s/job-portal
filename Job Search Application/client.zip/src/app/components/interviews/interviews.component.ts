import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interviews',
  templateUrl: './interviews.component.html',
  styleUrls: ['./interviews.component.sass']
})
export class InterviewsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
