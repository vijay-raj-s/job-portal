import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employer',
  templateUrl: './employer.component.html',
  styleUrls: ['./employer.component.sass']
})
export class EmployerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
