export interface LoginModel {
    token : string,
    email: string,
    password: string,
    error: boolean
}
