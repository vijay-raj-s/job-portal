const catchAsync = require('../utils/catchAsync');
const { validationResult} = require("express-validator"); 
const JobSeeker = require("../model/JobSeeker");
const JobApplication = require("../model/Application"); 
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const neo4j = require("../config/neo_db");
const _limit = 5;


const applyJob = catchAsync(async (req, res) => {
    //Getting job details from client
    const {
        jobId,
        employerId
    } = req.body;
    const jobSeekerId = req.jobSeeker.id;

    try {

        const application = await JobApplication.findOne({
            jobId,
            jobSeekerId
        });
        if (application)
        return res.status(400).json({
          message: "Already Applied"
        });

        
        let jobApplication = new JobApplication({
            jobId : jobId,
            employerId: employerId,
            status: 'pending',
            jobSeekerId: req.jobSeeker.id
        });   
        await jobApplication.save(); 
        res.status(200).json({ message: "Succesfully applied for the job!"});
    } catch (err) {
        console.log(err.message);
        res.status(500).send("Error in Saving job application");
    }
});

const updateJob = catchAsync();

const getApplications = catchAsync(async (req, res) => {
    try {
      
      let aggregate_options = [];

      let page = req.query.page ? parseInt(req.query.page) : 1;
      let limit = req.query.limit ? parseInt(req.query.limit) : _limit;

      const options = {
          page, limit,
          collation: {locale: 'en'},
          customLabels: {
              totalDocs: 'totalResults',
              docs: 'jobApplications'
          }
      };

      let match = {};

      // if (req.query.q) match.jobTitle = {$regex: req.query.q, $options: 'i'};
      match.employerId = ObjectId(req.employer.id);
      
      if(req.query.jobId){
        match.jobId = ObjectId(req.query.jobId);
      }c

      aggregate_options.push({$match: match});

      let sortOrder = req.query.sort_order && req.query.sort_order === 'asc' ? 1 : -1;
      aggregate_options.push({$sort: {"createdAt": sortOrder}});
      console.log('order');
      aggregate_options.push({$lookup: {from: 'jobseekers', localField: "jobSeekerId", foreignField: "_id", as: "jobSeeker"}});
      aggregate_options.push({$lookup: {from: 'jobs', localField: "jobId", foreignField: "_id", as: "job"}});
      
      const myAggregate = JobApplication.aggregate(aggregate_options);
      
      const result = await JobApplication.aggregatePaginate(myAggregate, options); 
      
      res.status(200).json(result); 
    } catch (e) {
      res.send({ message: "Error in Fetching Applications" });
    }
  });

const getAllJobApplications = catchAsync(async (req, res) => {
  try {
      
    let aggregate_options = [];

    let page = req.query.page ? parseInt(req.query.page) : 1;
    let limit = req.query.limit ? parseInt(req.query.limit) : 50;

    const options = {
        page, limit,
        collation: {locale: 'en'},
        customLabels: {
            totalDocs: 'totalResults',
            docs: 'jobApplications'
        }
    };

    let match = {};
 
    if(req.query.jobId){
      match.jobId = ObjectId(req.query.jobId);
    }

    aggregate_options.push({$match: match});

    let sortOrder = req.query.sort_order && req.query.sort_order === 'asc' ? 1 : -1;
    aggregate_options.push({$sort: {"createdAt": sortOrder}});
    console.log('order');
    aggregate_options.push({$lookup: {from: 'jobseekers', localField: "jobSeekerId", foreignField: "_id", as: "jobSeeker"}});
    aggregate_options.push({$lookup: {from: 'jobs', localField: "jobId", foreignField: "_id", as: "job"}});
    
    const myAggregate = JobApplication.aggregate(aggregate_options);
    
    const result = await JobApplication.aggregatePaginate(myAggregate, options);  
    res.status(200).json(result); 
  } catch (e) {
    console.log(e);
    res.send({ message: "Error in creating nodes" });
  }
});

const createNodesForRecommendation = catchAsync ( async(req,res) => {

    const session = neo4j.driver.session();
    const url = 'http://localhost:4000/application/getAllApplications';
    console.log("inside create node"); 
    const token = req.headers.token;
    const cypher = `// Creating graph  
                    WITH '${url}' AS uri
                    CALL apoc.load.jsonParams(uri, {token: '${token}' }, null)
                    YIELD value
                    WITH value.jobApplications as applications 
                    UNWIND applications as application 
                    MERGE (j:Job {name: application.job[0].jobTitle, jobId: application.job[0]._id }) 
                    MERGE (l:Location {name: coalesce(application.job[0].location, "unknown")})
                    MERGE (jt:JobType {name: coalesce(application.job[0].jobType, "unknown")})
                    MERGE (js:JobSeeker {name:application.jobSeeker[0].jobSeekerName, jobseekerId: application.jobSeeker[0]._id})
                    MERGE (exp:Experience {name: coalesce(application.jobSeeker[0].experience, "unknown")})
                    MERGE (jst:JobType {name: coalesce(application.jobSeeker[0].jobType, "unknown")})
                    MERGE (jsl:Location {name: coalesce(application.jobSeeker[0].location, "unknown")})
                    MERGE (des:Designation {name: coalesce(application.jobSeeker[0].designation, "unknown")})
                    
                    MERGE (js)-[:HAS_APPLIED_FOR]->(j)
                    MERGE (js)-[:HAS_EXPERIENCE]->(exp)
                    MERGE (js)-[:HAS_DESIGNATION]->(des)
                    MERGE (j)-[:HAS_JOB_TYPE]->(jt)
                    MERGE (js)-[:WANTS_JOB_TYPE]->(jst)
                    MERGE (js)-[:LIVES_IN]->(jsl)
                    MERGE (j)-[:LOCATED_IN]->(l)`;
               
      session.run(cypher)
        .then(result => { 
          console.log("----------------------------CREATING SKILLS---------------------------------")
          console.log(token);
          const cypher = `// creating skills 
                          WITH '${url}' AS uri
                          CALL apoc.load.jsonParams(uri, {token: '${token}' }, null)
                          YIELD value
                          WITH value.jobApplications as applications 
                          UNWIND applications as application  
                          UNWIND application.jobSeeker as jobSeeker 
                          MATCH (js:JobSeeker {name: jobSeeker.jobSeekerName }) 

                          WITH jobSeeker, js
                          UNWIND jobSeeker.skills as skill
                          MERGE (sk:Skills {name:toLower(skill)})
                          MERGE (js)-[:HAS_SKILL]->(sk)`;
                          
            session.run(cypher)
              .then(result => { 
                res.status(200).json({ "message": "Successfully created nodes" });
            }).catch(e => {
              console.log(e);
            })
            .then(() => {
              console.log("Closing session!");
              return session.close();
            });
      }).catch(e => {
        console.log(e);
      })
})

const getSingleApplication = catchAsync();
 
module.exports = {
    getApplications,
    getSingleApplication,
    applyJob,
    getAllJobApplications,
    createNodesForRecommendation
}